sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("nsbtp.modulefi.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);